# 4M — Members Make More Money · setup

Three steps: Supabase (the database), the Google Sheet mirror (optional), Vercel (the link members open).

---

## 1. Supabase — the shared database

### 1a. Create the table
Open your project → **SQL Editor** → New query → paste and run:

```sql
create table public.activities (
  cid       text primary key,
  ts        bigint       not null,
  member    text         not null,
  team      text         not null,
  type      text         not null,
  label     text         not null,
  detail    text,
  points    integer      not null default 0,
  comments  text,
  partner   text,
  created_at timestamptz not null default now()
);

alter table public.activities enable row level security;

-- Members submit their own activity, and the app reads the chapter totals.
create policy "anyone can insert" on public.activities
  for insert to anon with check (true);

create policy "anyone can read" on public.activities
  for select to anon using (true);

-- No updates or deletes from the app. You edit rows in the Supabase table editor.
```

### 1b. Connected — done
The table is created and the app is wired to your project:

```js
const CFG = {
  url: "https://jfztrbmgaudklzwscugo.supabase.co",
  key: "sb_publishable_RtnVY7ZS7N17xGVbv2VZAA_j0ibxsUG",
  sheet: ""
};
```

Tested end to end: insert 201, read 200, delete blocked by row-level security. The publishable key is safe in the file — the policies allow insert and read only, so no one can modify or delete data through the app.

---

## 2. Google Sheet mirror (optional)

1. Create a new Google Sheet, name it **4M Submissions**.
2. **Extensions → Apps Script**, delete what's there, paste:

```js
function doPost(e) {
  var d = JSON.parse(e.postData.contents);
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Log')
        || SpreadsheetApp.getActiveSpreadsheet().insertSheet('Log');
  if (sh.getLastRow() === 0) {
    sh.appendRow(['Timestamp','Member','Team','Activity','Detail','Points','Comments']);
  }
  sh.appendRow([d.ts, d.member, d.team, d.activity, d.detail, d.points, d.comments]);
  return ContentService.createTextOutput('ok');
}
```

3. **Deploy → New deployment → Web app.** Execute as *Me*, access *Anyone*. Deploy, authorise, copy the `/exec` URL.
4. Put that URL in `CFG.sheet`.

Every submission then appends a row. For the monthly leaderboard, add a second tab with:

```
=QUERY(Log!A:G, "select B, C, sum(F) where A is not null group by B, C order by sum(F) desc label sum(F) 'Points'")
```

---

## 3. Vercel — the link members open

The app is one HTML file plus its assets, so no build step.

1. Download the project (I can hand you a zip).
2. Rename `BNI Kaveri Game.dc.html` to `index.html`. Keep `support.js`, the `_ds/` folder and `assets/` next to it.
3. Go to **vercel.com → Add New → Project → deploy without a Git repository** (or drag the folder onto the Vercel CLI with `vercel deploy`).
4. You get a link like `4m-kaveri.vercel.app`. Add your own domain under **Settings → Domains** if you want `4m.khca.in`.

**Members:** open the link → iPhone: Share → *Add to Home Screen*. Android: ⋮ → *Add to home screen*. It then opens full-screen like an app.

---

## What the admin sees

Menu → Admin → PIN **1618** → team standings, tap a team for members, plus **All member submissions** with every entry, who logged it, points and comments. The Refresh button re-pulls from Supabase. Submissions made offline queue on the member's phone and upload on their next open.

## Disputes

The app is view-only for the admin by design. To reverse or adjust an entry, edit or delete the row in the Supabase table editor — the app reflects it on the next refresh.
